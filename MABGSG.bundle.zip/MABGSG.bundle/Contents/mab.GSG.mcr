macroScript GSGAssetImporter category:"MYARTSBOX" tooltip:"GSG Asset Importer"
(
    filein "mab.GSG.ms" 
)